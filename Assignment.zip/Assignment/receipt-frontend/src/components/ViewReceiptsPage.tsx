import { FC } from "react";

const ViewReceiptsPage: FC<unknown> = () => {
  return <></>;
};

export default ViewReceiptsPage;
